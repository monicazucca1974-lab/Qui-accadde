const locateButton = document.getElementById("locateButton");
const refreshButton = document.getElementById("refreshButton");
const statusBox = document.getElementById("status");
const resultsSection = document.getElementById("resultsSection");
const locationInfo = document.getElementById("locationInfo");
const resultsBox = document.getElementById("results");

const WIKIPEDIA_API = "https://it.wikipedia.org/w/api.php";

locateButton.addEventListener("click", startDiscovery);
refreshButton.addEventListener("click", startDiscovery);

function setLoading(message) {
  locateButton.disabled = true;
  statusBox.className = "status";
  statusBox.innerHTML = `<div class="loader"></div><div>${message}</div>`;
}

function clearLoading() {
  locateButton.disabled = false;
  statusBox.innerHTML = "";
}

function showError(message) {
  locateButton.disabled = false;
  statusBox.className = "status error";
  statusBox.textContent = message;
}

async function startDiscovery() {
  if (!navigator.geolocation) {
    showError("Questo browser non supporta la posizione GPS.");
    return;
  }

  setLoading("Sto cercando la tua posizione…");

  navigator.geolocation.getCurrentPosition(
    ({ coords }) => loadNearbyPlaces(coords.latitude, coords.longitude),
    handleLocationError,
    {
      enableHighAccuracy: true,
      timeout: 15000,
      maximumAge: 60000
    }
  );
}

function handleLocationError(error) {
  const messages = {
    1: "Permesso posizione negato. Tocca il lucchetto o le impostazioni del browser e consenti la posizione per questo sito.",
    2: "Non riesco a rilevare la posizione. Attiva il GPS e riprova.",
    3: "La ricerca della posizione ha impiegato troppo tempo. Riprova all'aperto o vicino a una finestra."
  };
  showError(messages[error.code] || "Errore durante la ricerca della posizione.");
}

async function loadNearbyPlaces(latitude, longitude) {
  try {
    setLoading("Cerco luoghi storici nelle vicinanze…");

    const params = new URLSearchParams({
      action: "query",
      generator: "geosearch",
      ggsprimary: "all",
      ggsnamespace: "0",
      ggsradius: "10000",
      ggslimit: "12",
      ggscoord: `${latitude}|${longitude}`,
      prop: "pageimages|extracts|coordinates",
      piprop: "thumbnail",
      pithumbsize: "700",
      exintro: "1",
      explaintext: "1",
      exsentences: "3",
      redirects: "1",
      format: "json",
      origin: "*"
    });

    const response = await fetch(`${WIKIPEDIA_API}?${params}`);
    if (!response.ok) throw new Error("Errore di rete");

    const data = await response.json();
    const pages = Object.values(data.query?.pages || [])
      .filter(page => page.title && page.extract)
      .sort((a, b) => (a.index || 999) - (b.index || 999))
      .slice(0, 8);

    if (!pages.length) {
      throw new Error("Nessun luogo trovato");
    }

    locationInfo.textContent =
      `Posizione rilevata: ${latitude.toFixed(5)}, ${longitude.toFixed(5)} · ricerca entro 10 km`;

    resultsBox.innerHTML = pages.map(page => createCard(page, latitude, longitude)).join("");
    resultsSection.classList.remove("hidden");
    clearLoading();
    resultsSection.scrollIntoView({ behavior: "smooth", block: "start" });
  } catch (error) {
    console.error(error);
    showError("Non sono riuscito a recuperare i luoghi vicini. Controlla la connessione e riprova.");
  }
}

function createCard(page, userLat, userLon) {
  const coordinates = page.coordinates?.[0];
  const distance = coordinates
    ? calculateDistance(userLat, userLon, coordinates.lat, coordinates.lon)
    : null;

  const titleEncoded = encodeURIComponent(page.title.replaceAll(" ", "_"));
  const articleUrl = `https://it.wikipedia.org/wiki/${titleEncoded}`;
  const mapUrl = coordinates
    ? `https://www.google.com/maps/search/?api=1&query=${coordinates.lat},${coordinates.lon}`
    : `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(page.title)}`;

  const image = page.thumbnail?.source
    ? `<img class="card-image" src="${escapeHtml(page.thumbnail.source)}" alt="${escapeHtml(page.title)}" loading="lazy">`
    : `<div class="card-placeholder">🏛️</div>`;

  return `
    <article class="card">
      ${image}
      <div class="card-content">
        <div class="card-meta">
          <span>📍 ${distance !== null ? formatDistance(distance) : "Nelle vicinanze"}</span>
        </div>
        <h3>${escapeHtml(page.title)}</h3>
        <p>${escapeHtml(shortenText(page.extract, 330))}</p>
        <div class="card-actions">
          <a class="link-button link-primary" href="${articleUrl}" target="_blank" rel="noopener">Leggi la storia</a>
          <a class="link-button link-secondary" href="${mapUrl}" target="_blank" rel="noopener">Apri mappa</a>
        </div>
      </div>
    </article>
  `;
}

function calculateDistance(lat1, lon1, lat2, lon2) {
  const earthRadiusKm = 6371;
  const toRadians = value => value * Math.PI / 180;
  const dLat = toRadians(lat2 - lat1);
  const dLon = toRadians(lon2 - lon1);

  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(toRadians(lat1)) *
    Math.cos(toRadians(lat2)) *
    Math.sin(dLon / 2) ** 2;

  return earthRadiusKm * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

function formatDistance(km) {
  if (km < 1) return `${Math.round(km * 1000)} metri`;
  return `${km.toFixed(1).replace(".", ",")} km`;
}

function shortenText(text, maxLength) {
  if (text.length <= maxLength) return text;
  return `${text.slice(0, maxLength).replace(/\s+\S*$/, "")}…`;
}

function escapeHtml(value) {
  return String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}
